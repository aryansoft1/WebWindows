
document.addEventListener('DOMContentLoaded', function() {
  console.log("窗口系统加载完成");
});
